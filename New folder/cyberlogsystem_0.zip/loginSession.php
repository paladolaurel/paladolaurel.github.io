<?php 

	if(!isset($_SESSION['loginUserStatus'])){
		header('location: index.php');
	}

 ?>