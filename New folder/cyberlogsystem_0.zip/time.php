<h2>
<?php 
	$time = time();
	echo date('D F d, Y g:i:s');
	// echo DATE("D F d, Y g:i:s", STRTOTIME($time)); 
	// echo '<br />';
	// echo date('g');
?>
</h2>

<!-- DATE("H:i", STRTOTIME("1:30 pm")); -->
