<script type="text/javascript">
	print();
</script>
