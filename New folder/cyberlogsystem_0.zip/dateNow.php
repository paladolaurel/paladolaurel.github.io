	<h2>Date: <?php echo date('m/d/Y'); ?></h2>
